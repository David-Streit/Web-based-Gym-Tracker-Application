# Gym Tracker FastAPI integration (additive)

Copy the `api/` folder and `tests/test_fastapi_health.py` into the existing
`Advanced_Programming-main/` folder. The existing application, services, models,
and UI remain unchanged.

In `Advanced_Programming-main/requirements.txt`, add:

```
fastapi
uvicorn[standard]
```

Your existing requirements should remain installed (`nicegui`, `sqlalchemy`).
For tests install `httpx` as an additional development dependency (`pip install httpx`).

From `Advanced_Programming-main/`:

```
python -m pip install -r requirements.txt
python -m uvicorn api.main:app --reload
```

Visit http://127.0.0.1:8000/docs and try `GET /api/health`.
For workout/exercise requests, click **Authorize** in Swagger and enter an
existing normal (non-admin) Gym Tracker user's credentials (HTTP Basic).
Use HTTPS for any non-local access. Do not deploy HTTP Basic over plain HTTP.

To run the tests:

```
python -m pip install pytest httpx
python -m pytest tests/test_fastapi_health.py
```

## Implemented
- Health: GET /api/health
- Workouts: GET list, GET detail, POST, PUT, DELETE
- Exercises: GET list, POST, DELETE
- Uses existing SQLAlchemy database and workout/auth services.
- Per-user filtering via existing service methods; avoids client-supplied user IDs.

## Scope / limitations
- This exposes the **current** workout model (date, notes, muscle IDs), not the
  future exercises + individual sets feature in the README.
- No modifications to original files other than appending dependencies.
- This is a separate FastAPI process; current NiceGUI application still runs as before.
- HTTP Basic is suitable only as an initial prototype under HTTPS; migrate to
  secure session/token authentication before public deployment.
- The existing `init_db` seeds an admin account with insecure fallback credentials;
  set secure ADMIN_USERNAME and ADMIN_PASSWORD and do not expose the app publicly with defaults.
- No CORS needed for Swagger's same-origin API docs. Configure explicit origins
  if a browser frontend will be served from another origin.
- Current update_session lacks some validation present in create_session; improve
  the service as a later separate PR before release.
