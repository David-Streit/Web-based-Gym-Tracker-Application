"""Standalone FastAPI app; does not replace the existing NiceGUI entry point."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from db.engine import init_db
from api.routes import workouts, exercises


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Gym Progress Tracker API", version="0.1.0", lifespan=lifespan)
app.include_router(workouts.router)
app.include_router(exercises.router)


@app.get("/api/health", tags=["health"])
def health_check():
    return {"status": "ok"}
