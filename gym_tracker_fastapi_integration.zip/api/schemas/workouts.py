from datetime import date
from pydantic import BaseModel, Field


class WorkoutWrite(BaseModel):
    workout_date: date
    notes: str | None = None
    muscle_ids: list[int] = Field(min_length=1)


class WorkoutCreated(BaseModel):
    id: int


class WorkoutListItem(BaseModel):
    id: int
    date: date
    notes: str | None
    muscle_names: list[str]


class WorkoutDetail(BaseModel):
    id: int
    date: date
    notes: str | None
    muscle_ids: list[int]


class ExerciseWrite(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class ExerciseItem(BaseModel):
    id: int
    name: str
